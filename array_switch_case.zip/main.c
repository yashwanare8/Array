/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int n,a[10];
int main()
{
	int choice;
	printf("\n enter the size of the array:");
	scanf("%d",&n);
	while(1) {
		printf("\n 1.cresation of an array");
		printf("\n 2.insertion of element at first position");
		printf("\n 3.insertion of element at any position");
		printf("\n 4.insertion of element at last position");
		printf("\n 5.delection of element at first position");
		printf("\n 6.delection of element at any position");
		printf("\n 7.delection of element at last position");
		printf("\n 8.display");
		printf("\n\n enter the choice:");
		scanf("%d",&choice);
		switch (choice) {
		case 1:
			printf(" enter the element of the array");
			for (int i=0; i<n; i++) {
				scanf("%d",&a[i]);}

				break;
			case 2:
				printf(" enter the element at first position");
				for (int i=0; i>0; i++) {
					scanf("%d",&a[i]);
					a[i]=a[i-1];}
					break;

				case 3:
					printf(" enter the element at any position");
					for (int i=0; i>0; i++) {
						scanf("%d",&a[i]);
						a[i]=a[i+1]; }// shifting of array
						break;

					case 4:
						printf(" enter the element at last position");
						for (int i=0; i>0; i++) {
							scanf("%d",&a[i]);
							a[n]=a[i];}
							break;

						case 5:
							printf(" delectionthe element at first position");
							for (int i=0; i>0; i++) {
								scanf("%d",&a[i]);
								a[i]=a[i+1];}
								n--;
								break;

							/* case 6:
							 printf(" delection element at last position");
							     n--;
							     free(a[n]);
							     break;
							 }
							case 7:
							printf(" delectionthe element at any position");
							{ int p;
							 scanf("%d",&p);
							    for (int i=p-1;i<=n;i++){
							        a[i]=a[i+1];
							    }}
							     break;*/



	                       	  case 8:
								printf("display the elements");
								for(int i=0; i<n; i++) {
									printf("\n%d",a[i]);

								}
							}
						}


					
				
		
		

		return 0;
	}
